Jogar o jogo � simples; voc� � o ponto vermelho, e seu objetivo � se deslocar at� o ponto azul.
Para mover o ponto vermelho, voc� pode usar as teclas direcionais (que far�o com que ele se mova numa velocidade normal, se n�o um pouco lenta) ou as teclas A D W S (far�o com que o ponto se mova muito mais rapidamente), que representam as dire��es esquerda, direita, cima e baixo, respectivamente.
Toda vez que o ponto vermelho encostar no azul, o ponto azul vai mudar de localiza��o. Isso se repetir� infinitamente.
Se o ponto vermelho encostar em uma parede (linha branca), ele ir� voltar para sua posi��o inicial. Se isso acontecer 3 vezes, o jogo acaba (a janela do pygame fecha).
Deveria haver uma m�sica de fundo, mas eu n�o consegui fazer o upload do arquivo no GitHub. O arquivo de m�sica prcisa estar no mesmo diret�rio que o arquivo de Python para funcionar. Ent�o, se voc� quiser adicionar uma m�sica, voc� primeiro deve adicionar um arquivo .wav � pasta �Labirinto� (ou onde quer que seja que voc� mantem o arquivo do jogo). Depois, procure pygame.mixer.music.load() no c�digo do arquivo .py, e coloque o nome do arquivo dentro dos parenteses. Lembre-se de incluir a extens�o de arquivo junta ao nome, e de coloc�-lo entre aspas.
Ou, se voc� n�o quiser nenhuma m�sica, voc� pode apagar as linhas de c�digo:
if music == False:
    music = True
    pygame.mixer.music.load()
    pygame.mixer.music.play(-1)

Para ter mais facilidade em achar os c�digos, voc� pode apertar Ctrl + F e digitar �mixer�.
