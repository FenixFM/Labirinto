#_*_coding:latin1_*_

import pygame
from pygame.locals import *
import random
pygame.font.init()
clock = pygame.time.Clock()
gameOver = 0

white = (255, 255,  255)
x = 22
y = 300
playerX = 0
playerY = 0
hardMode = False

gx = 0
gy = 0

gw = 0
gz = 0

def dotPosition():
    global gx, gy, gw, gz
    while gz == gw:
        gz = random.randint(1, 22)
    if gz == 1:
        gx, gy = 42, 42
    elif gz == 2:
        gx, gy = 758, 42
    elif gz == 3:
        gx, gy = 758, 558
    elif gz == 4:
        gx, gy = 42, 558
    elif gz == 5:
        gx, gy = 400, 170
    elif gz == 6:
        gx, gy = 400, 430
    elif gz == 7:
        gx, gy = 222, 170
    elif gz == 8:
        gx, gy = 578, 172
    elif gz == 9:
        gx, gy = 578, 430
    elif gz == 10:
        gx, gy = 222, 430
    elif gz == 11:
        gx, gy = 222, 72
    elif gz == 12:
        gx, gy = 222, 270
    elif gz == 13:
        gx, gy = 72, 170
    elif gz == 14:
        gx, gy = 578, 72
    elif gz == 15:
        gx, gy = 578, 270
    elif gz == 16:
        gx, gy = 728, 170
    elif gz == 17:
        gx, gy = 578, 528
    elif gz == 18:
        gx, gy = 578, 330
    elif gz == 19:
        gx, gy = 728, 430
    elif gz == 20:
        gx, gy = 222, 528
    elif gz == 21:
        gx, gy = 222, 330
    elif gz == 22:
        gx, gy = 72, 430
    gw = gz

screen = pygame.display.set_mode((800, 600))

music = False
dotPosition()
gameExit = False
pygame.init()
while not gameExit:
    if music == False:
        music = True
        pygame.mixer.music.load()
        pygame.mixer.music.play(-1)
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            gameExit = True

    screen.fill((0, 0, 0))
    b1 = pygame.draw.rect(screen, white, (2, 2, 30, 288))
    b2 = pygame.draw.rect(screen, white, (2, 2, 796, 30))
    b3 = pygame.draw.rect(screen, white, (768, 2, 30, 596))
    b4 = pygame.draw.rect(screen, white, (2, 568, 796, 30))
    b5 = pygame.draw.rect(screen, white, (2, 310, 30, 288))
    b6 = pygame.draw.rect(screen, white, (2, 290, 10, 20))
    player = pygame.draw.circle(screen, (255, 0, 0), (x, y), 5, 0)

    w1 = pygame.draw.rect(screen, white, (52, 52, 10, 238))
    w2 = pygame.draw.rect(screen, white, (52, 310, 10, 238))
    w3 = pygame.draw.rect(screen, white, (52, 280, 338, 10))
    w4 = pygame.draw.rect(screen, white, (52, 310, 338, 10))
    w5 = pygame.draw.rect(screen, white, (52, 52, 338, 10))
    w6 = pygame.draw.rect(screen, white, (410, 52, 338, 10))
    w7 = pygame.draw.rect(screen, white, (52, 538, 338, 10))
    w8 = pygame.draw.rect(screen, white, (410, 538, 338, 10))
    w9 = pygame.draw.rect(screen, white, (738, 52, 10, 238))
    w10 = pygame.draw.rect(screen, white, (738, 310, 10, 238))
    w11 = pygame.draw.rect(screen, white, (410, 280, 338, 10))
    w12 = pygame.draw.rect(screen, white, (410, 310, 338, 10))
    w13 = pygame.draw.rect(screen, white, (380, 52, 10, 109))
    w14 = pygame.draw.rect(screen, white, (380, 181, 10, 109))
    w15 = pygame.draw.rect(screen, white, (410, 52, 10, 109))
    w16 = pygame.draw.rect(screen, white, (410, 181, 10, 109))
    w17 = pygame.draw.rect(screen, white, (380, 310, 10, 109))
    w18 = pygame.draw.rect(screen, white, (380, 439, 10, 109))
    w19 = pygame.draw.rect(screen, white, (410, 310, 10, 109))
    w20 = pygame.draw.rect(screen, white, (410, 439, 10, 109))
    w21 = pygame.draw.rect(screen, white, (82, 82, 129, 77), 7)
    w22 = pygame.draw.rect(screen, white, (82, 183, 129, 77), 7)
    w23 = pygame.draw.rect(screen, white, (231, 82, 129, 77), 7)
    w24 = pygame.draw.rect(screen, white, (231, 183, 129, 77), 7)
    w25 = pygame.draw.rect(screen, white, (440, 82, 129, 77), 7)
    w26 = pygame.draw.rect(screen, white, (440, 183, 129, 77), 7)
    w27 = pygame.draw.rect(screen, white, (589, 82, 129, 77), 7)
    w28 = pygame.draw.rect(screen, white, (589, 183, 129, 77), 7)
    w29 = pygame.draw.rect(screen, white, (82, 341, 129, 77), 7)
    w30 = pygame.draw.rect(screen, white, (82, 443, 129, 77), 7)
    w31 = pygame.draw.rect(screen, white, (231, 341, 129, 77), 7)
    w32 = pygame.draw.rect(screen, white, (231, 443, 129, 77), 7)
    w33 = pygame.draw.rect(screen, white, (440, 341, 129, 77), 7)
    w34 = pygame.draw.rect(screen, white, (440, 443, 129, 77), 7)
    w35 = pygame.draw.rect(screen, white, (589, 341, 129, 77), 7)
    w36 = pygame.draw.rect(screen, white, (589, 443, 129, 77), 7)
    goal = pygame.draw.circle(screen, (0, 0, 255), (gx, gy), 5, 0)

    def collision():
        global x, y, gameOver
        if player.colliderect(b1) or player.colliderect(b2) or player.colliderect(b3) or player.colliderect(b4) or \
        player.colliderect(b5) or player.colliderect(b6) or player.colliderect(w1) or player.colliderect(w2) or \
        player.colliderect(w3) or player.colliderect(w4) or player.colliderect(w5) or player.colliderect(w6) or \
        player.colliderect(w7) or player.colliderect(w8) or player.colliderect(w9) or player.colliderect(w10) or \
        player.colliderect(w11) or player.colliderect(w12) or player.colliderect(w13) or player.colliderect(w14) or \
        player.colliderect(w15) or player.colliderect(w16) or player.colliderect(w17) or player.colliderect(w18) or \
        player.colliderect(w19) or player.colliderect(w20) or player.colliderect(w21) or player.colliderect(w22) or \
        player.colliderect(w23) or player.colliderect(w24) or player.colliderect(w25) or player.colliderect(w26) or \
        player.colliderect(w27) or player.colliderect(w28) or player.colliderect(w29) or player.colliderect(w30) or \
        player.colliderect(w31) or player.colliderect(w32) or player.colliderect(w33) or player.colliderect(w34) or \
        player.colliderect(w35) or player.colliderect(w36):
            x, y = 20, 300
            gameOver += 1

    if e.type == pygame.KEYDOWN:
        if e.key == K_LEFT:
            hardMode = False
            playerX = -1
            collision()
        if e.key == K_RIGHT:
            hardMode = False
            playerX = 1
            collision()
        if e.key == K_UP:
            hardMode = False
            playerY = -1
            collision()
        if e.key == K_DOWN:
            hardMode = False
            playerY = 1
            collision()
    if e.type == pygame.KEYUP:
        if e.key == K_LEFT:
            playerX = 0
            collision()
        if e.key == K_RIGHT:
            playerX = 0
            collision()
        if e.key == K_UP:
            playerY = 0
            collision()
        if e.key == K_DOWN:
            playerY = 0
            collision()

    if e.type == pygame.KEYDOWN:
        if e.key == K_a:
            hardMode = True
            playerX = -1
            collision()
        if e.key == K_d:
            hardMode = True
            playerX = 1
            collision()
        if e.key == K_w:
            hardMode = True
            playerY = -1
            collision()
        if e.key == K_s:
            hardMode = True
            playerY = 1
            collision()
    if e.type == pygame.KEYUP:
        if e.key == K_a:
            hardMode = True
            playerX = 0
            collision()
        if e.key == K_d:
            hardMode = True
            playerX = 0
            collision()
        if e.key == K_w:
            hardMode = True
            playerY = 0
            collision()
        if e.key == K_s:
            hardMode = True
            playerY = 0
            collision()

    x += playerX
    y += playerY

    if gameOver == 3:
        gameExit = True
    if player.colliderect(goal):
        dotPosition()
        goal = pygame.draw.circle(screen, (0, 0, 255), (gx, gy), 5, 0)

    if not hardMode:
        clock.tick(60)
    else:
        clock.tick(1000)

    pygame.display.update()